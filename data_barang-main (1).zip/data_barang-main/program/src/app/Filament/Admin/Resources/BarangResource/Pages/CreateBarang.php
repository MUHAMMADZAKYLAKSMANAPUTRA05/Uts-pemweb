<?php

namespace App\Filament\Admin\Resources\BarangResource\Pages;

use App\Filament\Admin\Resources\BarangResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBarang extends CreateRecord
{
    protected static string $resource = BarangResource::class;
}
